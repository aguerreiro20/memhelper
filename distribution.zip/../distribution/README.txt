Java needs to be installed to execute the JAR file, it can be downloaded from here:
https://www.oracle.com/java/technologies/downloads/#jdk21-windows

Direct download link:
https://download.oracle.com/java/21/latest/jdk-21_windows-x64_bin.exe
